import logo from './logo_large.png'
export const logoNegative = [
  '608 134',
  `
  <title>coreui react pro logo</title>
  <img src=`+logo+`>
`,
]
